"""Local bridge storage and discovery. No bpy access, shell commands or services."""
import json
from functools import lru_cache
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time
import uuid

RETENTION_SECONDS = 7 * 86400
_cleanup_cursor = ""


@lru_cache(maxsize=16)
def _has_bridge_cli(path, size, modified_ns, refresh=False, export_wait=False):
    """Inspect existing native CLI literals without executing a legacy viewer.

    Original public builds treat unknown options as filenames, so launching a
    capability probe would itself open an error dialog. Cache by file identity
    metadata to keep Preferences drawing cheap and notice replaced executables.
    """
    required = {flag.encode('utf-16-le') for flag in ('--import-fbx', '--bridge-session')}
    if refresh:
        required.add('--bridge-refresh-v1'.encode('utf-16-le'))
    if export_wait:
        required.add('--bridge-wait-export-v1'.encode('utf-16-le'))
    overlap = max(map(len, required)) - 1
    with open(path, 'rb') as stream:
        header = stream.read(64)
        if len(header) < 64 or header[:2] != b'MZ':
            return False
        stream.seek(int.from_bytes(header[60:64], 'little'))
        if stream.read(6) != b'PE\0\0\x64\x86':
            return False
        stream.seek(0)
        tail = b''
        while chunk := stream.read(256 * 1024):
            chunk = tail + chunk
            required = {flag for flag in required if flag not in chunk}
            if not required:
                return True
            tail = chunk[-overlap:]
    return False


def supports_bridge_cli(path):
    info = path.stat()
    return _has_bridge_cli(str(path), info.st_size, info.st_mtime_ns)


def supports_refresh_cli(path):
    info = path.stat()
    return _has_bridge_cli(str(path), info.st_size, info.st_mtime_ns, True)


def supports_export_wait_cli(path):
    info = path.stat()
    return _has_bridge_cli(str(path), info.st_size, info.st_mtime_ns, export_wait=True)


def redirected(path):
    return bool(path.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)


def export_root():
    base = os.environ.get("LOCALAPPDATA")
    if not base:
        raise RuntimeError("LOCALAPPDATA is unavailable; cannot create an export session.")
    return Path(base) / "ArtInspector" / "Bridge" / "Exports"


def _workspace_executables():
    """Find sibling portable builds when running from a workspace or release ZIP."""
    for parent in Path(__file__).resolve().parents:
        builds = parent / "ArtInspector_Builds" / "Art-Inspector"
        for channel in ("Shipped", "Develop"):
            yield builds / channel / "ArtInspector.exe"


def resolve_executable(configured="", require_refresh=False):
    if configured:
        candidates = [Path(configured).expanduser()]
    else:
        candidates = []
        if os.environ.get("ARTINSPECTOR_EXE"):
            candidates.append(Path(os.environ["ARTINSPECTOR_EXE"]))
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\ArtInspector\Bridge") as key:
                candidates.append(Path(winreg.QueryValueEx(key, "Executable")[0]))
        except (ImportError, OSError):
            pass
        candidates.extend(_workspace_executables())
        for key in ("LOCALAPPDATA", "ProgramFiles", "ProgramFiles(x86)"):
            if os.environ.get(key):
                base = Path(os.environ[key])
                candidates.extend((base / "ArtInspector" / "ArtInspector.exe",
                                   base / "Programs" / "ArtInspector" / "ArtInspector.exe"))
        found = shutil.which("ArtInspector.exe")
        if found:
            candidates.append(Path(found))
    for path in candidates:
        if path.name.lower() == "artinspector.exe" and path.is_file() and os.access(path, os.R_OK):
            path = path.resolve()
            try:
                compatible = supports_refresh_cli(path) if require_refresh else supports_bridge_cli(path)
            except OSError:
                compatible = False
            if compatible:
                return path
            if configured:
                if require_refresh and supports_bridge_cli(path):
                    raise RuntimeError(f"This ArtInspector.exe supports Export but not updating an open window. Choose the updated refresh-enabled build: {path}")
                raise RuntimeError(
                    f"This ArtInspector.exe does not support Blender Bridge (--import-fbx). Selected: {path}. "
                    "Choose the updated bridge-enabled ArtInspector.exe in add-on Preferences, "
                    "or clear Art Inspector Executable to use automatic discovery.")
    raise RuntimeError("A compatible ArtInspector.exe was not found or is inaccessible. Set Art Inspector Executable in add-on Preferences to the updated Blender Bridge build.")


class Lease:
    """Lock the same first byte as the native bridge; OS releases it on crashes."""
    def __init__(self, path):
        import msvcrt
        self.file = open(path, "a+b")
        try:
            self.file.seek(0, 2)
            if not self.file.tell():
                self.file.write(b"\0")
                self.file.flush()
            self.file.seek(0)
            msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
        except BaseException:
            self.file.close()
            raise

    def close(self):
        if not self.file.closed:
            import msvcrt
            self.file.seek(0)
            msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            self.file.close()


def write_json(path, data):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def write_export_state(folder, state):
    """Exporter-owned progress, separate from the viewer-owned status.json."""
    if state not in {'exporting', 'ready', 'failed'}:
        raise ValueError('Invalid export state.')
    path = folder / 'export-state.txt'
    temporary = folder / 'export-state.tmp'
    temporary.write_text(state + '\n', encoding='utf-8')
    # A native reader without FILE_SHARE_DELETE may briefly block atomic
    # replacement on Windows. Keep the completed marker and retry the rename.
    for attempt in range(30):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            if attempt == 29:
                raise
            time.sleep(.01)


def cleanup_old_sessions(root=None, now=None):
    """Only owned UUID folders, no reparse points, no active leases; bounded work."""
    root = root or export_root()
    now = now or time.time()
    if not root.exists():
        return
    # Never traverse a redirected root or its parents.
    if any(redirected(p) for p in (root, *root.parents)):
        return
    global _cleanup_cursor
    # Rotate batches so fresh/active folders cannot permanently starve older
    # sessions beyond the per-export work limit.
    folders = sorted(root.iterdir(), key=lambda p: p.name)
    folders = [p for p in folders if p.name > _cleanup_cursor] + [p for p in folders if p.name <= _cleanup_cursor]
    referenced = set()
    for anchor in folders:
        try:
            if redirected(anchor) or not anchor.is_dir() or not (anchor/'session.lock').is_file():
                continue
            try:
                probe = Lease(anchor/'session.lock')
            except OSError:
                for request in anchor.glob('refresh-*.request'):
                    token = request.name[8:-8]
                    if valid_uuid(token) and not redirected(request):
                        referenced.add(token)
            else:
                probe.close()
        except OSError:
            continue
    scanned = 0
    for folder in folders:
        scanned += 1
        if scanned > 256:
            break
        _cleanup_cursor = folder.name
        lease = None
        try:
            if redirected(folder) or not folder.is_dir():
                continue
            if str(uuid.UUID(folder.name)) != folder.name:
                continue
            if folder.name in referenced:
                continue
            marker = folder / "manifest.json"
            if now - marker.stat().st_mtime < RETENTION_SECONDS:
                continue
            data = json.loads(marker.read_text(encoding="utf-8"))
            if data.get("owner") != "art_inspector_bridge_v1" or data.get("session_id") != folder.name:
                continue
            files = list(folder.iterdir())
            allowed = {"manifest.json", "selection.fbx", "session.lock", "status.json", "status.tmp", "diagnostic.txt", "model-key.txt", "export-state.txt", "export-state.tmp", "exporter-pid.txt"}
            def known_file(path):
                if path.name in allowed:
                    return True
                if path.name.startswith('refresh-'):
                    token = path.name[8:].removesuffix('.tmp').removesuffix('.request')
                    return path.name.endswith(('.request', '.request.tmp')) and valid_uuid(token)
                return False
            if any(not known_file(p) or redirected(p) or not p.is_file() for p in files):
                continue
            lease = Lease(folder / "session.lock")
            for path in files:
                if path.name != "session.lock":
                    path.unlink()
            lease.close()
            lease = None
            (folder / "session.lock").unlink()
            folder.rmdir()
        except (OSError, ValueError):
            pass
        finally:
            if lease:
                lease.close()


def allow_foreground(pid):
    """Pass Blender's user-initiated activation permission to this viewer only."""
    if os.name != 'nt':
        return False
    try:
        pid = int(pid)
        if not 0 < pid < 0xFFFFFFFF:
            return False
        import ctypes
        from ctypes import wintypes
        user = ctypes.WinDLL('user32', use_last_error=True)
        user.AllowSetForegroundWindow.argtypes = [wintypes.DWORD]
        user.AllowSetForegroundWindow.restype = wintypes.BOOL
        return bool(user.AllowSetForegroundWindow(pid))
    except (OSError, ValueError, TypeError):
        return False


def activate_window(pid):
    """Restore and foreground this process's Art Inspector main window."""
    if os.name != 'nt':
        return False
    import ctypes
    from ctypes import wintypes
    try:
        pid = int(pid)
        if not 0 < pid < 0xFFFFFFFF:
            return False
        user = ctypes.WinDLL('user32', use_last_error=True)
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
        user.EnumWindows.restype = wintypes.BOOL
        user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user.IsIconic.argtypes = [wintypes.HWND]
        user.IsIconic.restype = wintypes.BOOL
        user.ShowWindowAsync.argtypes = [wintypes.HWND, ctypes.c_int]
        user.SetForegroundWindow.argtypes = [wintypes.HWND]
        user.SetForegroundWindow.restype = wintypes.BOOL
        target = []

        @callback_type
        def find_window(hwnd, unused):
            owner = wintypes.DWORD()
            user.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            if owner.value == pid:
                name = ctypes.create_unicode_buffer(128)
                if user.GetClassNameW(hwnd, name, len(name)) and name.value == 'ArtyTexelDensityInspector':
                    target.append(hwnd)
                    return False
            return True

        user.EnumWindows(find_window, 0)
        if not target:
            return False
        allow_foreground(pid)
        # SW_RESTORE preserves the last placement; SW_SHOW keeps a maximized
        # window maximized. No permanent topmost state is applied.
        user.ShowWindowAsync(target[0], 9 if user.IsIconic(target[0]) else 5)
        return bool(user.SetForegroundWindow(target[0]))
    except (OSError, ValueError, TypeError):
        return False


def launch(executable, folder, wait_export=False):
    # Popen never waits for the viewer and never invokes a shell.
    command = [str(executable), '--import-fbx', str(folder / 'selection.fbx'), '--bridge-session', str(folder)]
    if (folder / 'model-key.txt').exists() and supports_refresh_cli(executable):
        command.append('--bridge-refresh-v1')
    if wait_export:
        command.append('--bridge-wait-export-v1')
    child = subprocess.Popen(command, cwd=str(executable.parent),
                             close_fds=True, creationflags=subprocess.CREATE_NO_WINDOW)
    # Do this immediately while Blender still owns the Export click's input;
    # native initialization can then activate its window when it is ready.
    allow_foreground(child.pid)
    activate_window(child.pid)
    return child


def valid_uuid(value):
    try:
        return str(uuid.UUID(value)) == value
    except ValueError:
        return False


def process_alive(pid):
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x1000, False, int(pid))
    if not handle:
        return False
    try:
        code = wintypes.DWORD()
        return bool(kernel.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259
    finally:
        kernel.CloseHandle(handle)


def session_is_live(folder, pid):
    if not process_alive(pid):
        return False
    try:
        lease = Lease(folder / 'session.lock')
    except OSError:
        return True
    lease.close()
    return False


def matching_session(root, model_key, legacy_identity=None):
    """Find a live document window, optionally adopting a proven 1.1.0 key."""
    candidates = []
    for folder in root.iterdir():
        try:
            if not valid_uuid(folder.name) or redirected(folder) or not folder.is_dir():
                continue
            manifest = json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
            status_path = folder/'status.json'
            status = json.loads(status_path.read_text(encoding='utf-8'))
            routing_key = status.get('model_key')
            matches = (routing_key == model_key or manifest.get('document_key') == model_key
                       or (legacy_identity is not None and routing_key == legacy_identity(manifest)))
            if (manifest.get('owner') == 'art_inspector_bridge_v1' and manifest.get('session_id') == folder.name
                    and status.get('bridge_refresh') is True and matches
                    and isinstance(routing_key, str) and len(routing_key) == 64
                    and status.get('anchor_session') == folder.name and status.get('state') != 'detached'
                    and session_is_live(folder, status.get('pid', 0))):
                candidates.append((status_path.stat().st_mtime_ns, folder, int(status['pid']), routing_key, manifest))
        except (OSError, ValueError, TypeError):
            continue
    if not candidates:
        return None
    _, folder, pid, routing_key, manifest = max(candidates, key=lambda item: (item[0], item[1].name))
    if manifest.get('document_key') != model_key:
        manifest['document_key'] = model_key
        write_json(folder/'manifest.json', manifest)
    return folder, pid, routing_key


def queue_refresh(target, export_folder, model_key):
    path = target / ('refresh-' + export_folder.name + '.request')
    temporary = path.with_suffix('.request.tmp')
    temporary.write_text(model_key + '\n', encoding='ascii')
    temporary.replace(path)
