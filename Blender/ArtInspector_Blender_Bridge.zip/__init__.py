# SPDX-License-Identifier: GPL-3.0-or-later
"""Art Inspector Blender Bridge. All bpy work runs on Blender's main thread."""
import os
import hashlib
import json
from pathlib import Path
import time
import uuid

import bpy
from bpy.props import StringProperty, EnumProperty
from bpy.app.handlers import persistent
from . import session

_document_token = str(uuid.uuid4())
_delivery_timers = set()


@persistent
def reset_document_identity(unused):
    global _document_token
    _document_token = str(uuid.uuid4())
    _delivery_timers.clear()


def document_identity():
    document = os.path.normcase(os.path.abspath(bpy.data.filepath)) if bpy.data.filepath else 'unsaved:' + _document_token
    return document


def model_identity(meshes=None):
    """A window belongs to the document; its current selection is only payload."""
    return hashlib.sha256(json.dumps(['blend-document-v1', document_identity()], ensure_ascii=False).encode('utf-8')).hexdigest()


def legacy_identity(manifest):
    """Prove an existing 1.1.0 session belongs to this full document path.

    Never adopt a window using just a blend basename or overlapping selection.
    If old exported objects disappeared, the legacy association is unprovable.
    """
    names = manifest.get('mesh_names')
    if not isinstance(names, list) or not names or any(not isinstance(name, str) for name in names):
        return None
    objects = [bpy.data.objects.get(name) for name in names]
    if any(obj is None or obj.type != 'MESH' for obj in objects):
        return None
    identities = sorted((obj.name_full, obj.library.filepath if obj.library else '') for obj in objects)
    return hashlib.sha256(json.dumps([document_identity(), identities], ensure_ascii=False).encode('utf-8')).hexdigest()


class BridgePreferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    executable: StringProperty(name="Art Inspector Executable", subtype='FILE_PATH',
                              description="Bridge-enabled ArtInspector.exe; empty uses automatic discovery")
    export_mode: EnumProperty(name='Export Mode', default='NEW_WINDOW', items=(
        ('NEW_WINDOW', 'New window every time', 'Open a new independent Art Inspector window for each Export'),
        ('UPDATE_EXISTING', 'Update matching window', 'Replace the model in this blend file\'s window, regardless of selected Mesh set, preserving view and checker settings')))

    def draw(self, context):
        self.layout.prop(self, "executable")
        self.layout.prop(self, 'export_mode')
        try:
            exe = session.resolve_executable(bpy.path.abspath(self.executable) if self.executable else "", self.export_mode == 'UPDATE_EXISTING')
            self.layout.label(text=str(exe), icon='CHECKMARK')
        except RuntimeError as error:
            self.layout.label(text=str(error), icon='ERROR')


def export_selection(context, executable, export_mode='NEW_WINDOW'):
    if os.name != "nt":
        raise RuntimeError("Art Inspector Bridge V1 requires Windows x64.")
    if context.mode != 'OBJECT':
        raise RuntimeError("Switch to Object Mode before exporting. Your mode and selection have been preserved.")
    selected = tuple(context.selected_objects)
    meshes = tuple(obj for obj in selected if obj.type == 'MESH')
    if not meshes:
        raise RuntimeError("Select at least one Mesh object.")
    if export_mode not in ('NEW_WINDOW', 'UPDATE_EXISTING'):
        raise RuntimeError('Unknown Export Mode.')
    executable = session.resolve_executable(executable, export_mode == 'UPDATE_EXISTING')
    early_viewer = session.supports_export_wait_cli(executable)
    document_key = model_identity()
    root = session.export_root()
    root.mkdir(parents=True, exist_ok=True)
    session.cleanup_old_sessions(root)
    target = session.matching_session(root, document_key, legacy_identity) if export_mode == 'UPDATE_EXISTING' else None
    if target and early_viewer:
        # The EXE on disk can be newer than a still-running window. Old native
        # sessions discard refresh requests whose FBX has not been written yet.
        try:
            live_status = json.loads((target[0] / 'status.json').read_text(encoding='utf-8'))
            early_viewer = live_status.get('export_wait') is True
        except (OSError, ValueError):
            early_viewer = False
    # Adopted 1.1.0 viewers retain their native routing key until they close.
    model_key = target[2] if target else document_key
    folder = root / str(uuid.uuid4())
    folder.mkdir()
    lease = session.Lease(folder / "session.lock")
    manifest = dict(owner="art_inspector_bridge_v1", session_id=folder.name,
                    source_application="Blender", blender_version=bpy.app.version_string,
                    blend_file=Path(bpy.data.filepath).name, export_timestamp=time.time(),
                    mesh_count=len(meshes), mesh_names=[o.name for o in meshes], fbx="selection.fbx",
                    model_key=model_key, document_key=document_key)
    existing_meshes = set(bpy.data.meshes)
    child = None
    context.window_manager.progress_begin(0, 3)
    try:
        session.write_json(folder / "manifest.json", manifest)
        (folder / 'model-key.txt').write_text(model_key + '\n', encoding='ascii')
        (folder / 'exporter-pid.txt').write_text(str(os.getpid()) + '\n', encoding='ascii')
        session.write_export_state(folder, 'exporting')
        if target:
            anchor, pid, _ = target
            session.activate_window(pid)
            if early_viewer:
                # Native observes the request while this exporter still owns
                # the handoff lease, showing progress without reading the FBX.
                session.queue_refresh(anchor, folder, model_key)
        elif early_viewer:
            # The viewer needs its lease immediately to open a responsive
            # window. export-state.txt prevents import of a partial FBX.
            lease.close()
            child = session.launch(executable, folder, wait_export=True)
        # Evaluation can itself take time on modifier-heavy scenes, so open
        # the viewer before asking Blender to prepare evaluated geometry.
        depsgraph = context.evaluated_depsgraph_get()
        # Native FBX instancing may pull unselected source objects into the file.
        # Reject these cases instead of silently exporting extra geometry.
        for instance in depsgraph.object_instances:
            if instance.is_instance and instance.parent and instance.parent.original in meshes:
                raise RuntimeError("Selected mesh generates instances. Realize Instances in Geometry Nodes (or use real mesh objects) before Export.")
        context.window_manager.progress_update(1)
        # Context override changes the export list without changing selection.
        # FBX creates temporary evaluated/copied meshes; original data stays intact.
        with context.temp_override(selected_objects=meshes, active_object=meshes[0], object=meshes[0]):
            result = bpy.ops.export_scene.fbx(
                filepath=str(folder / "selection.fbx"), check_existing=False,
                use_selection=True, use_visible=False, use_active_collection=False,
                object_types={'MESH'}, bake_anim=False, use_mesh_modifiers=True,
                use_mesh_modifiers_render=False, use_subsurf=False,
                # FBX's BMesh triangulation can change evaluated split normals.
                # Preserve polygons/normals; the existing ufbx importer triangulates.
                use_triangles=False, mesh_smooth_type='OFF', colors_type='LINEAR',
                prioritize_active_color=True, apply_unit_scale=True,
                apply_scale_options='FBX_SCALE_UNITS', global_scale=1.0,
                axis_forward='-Z', axis_up='Y', use_space_transform=True,
                bake_space_transform=False, path_mode='STRIP', embed_textures=False)
        if 'FINISHED' not in result or not (folder / "selection.fbx").is_file() or (folder / "selection.fbx").stat().st_size < 32:
            raise RuntimeError("Blender FBX export did not produce a valid file.")
        session.write_export_state(folder, 'ready')
        context.window_manager.progress_update(2)
        if not early_viewer:
            session.write_json(folder / "status.json", dict(state="exported"))
        if target:
            anchor, pid, _ = target
            if not early_viewer:
                session.write_json(folder/'status.json', dict(state='queued', pid=pid, anchor_session=anchor.name))
                session.queue_refresh(anchor, folder, model_key)
            # If the window closes before accepting this request, start a new
            # viewer. This timer uses only main-thread file/process APIs.
            def ensure_delivery():
                try:
                    try:
                        delivery = json.loads((folder/'status.json').read_text(encoding='utf-8'))
                    except (OSError, ValueError):
                        delivery = {}
                    # Once native has claimed the ready request, it owns its
                    # outcome (including an import failure); do not duplicate it.
                    if delivery.get('state') in {'starting', 'loading', 'loaded', 'failed'}:
                        _delivery_timers.discard(ensure_delivery)
                        return None
                    alive = session.session_is_live(anchor, pid)
                    detached = False
                    if alive:
                        try:
                            status = json.loads((anchor/'status.json').read_text(encoding='utf-8'))
                            detached = status.get('state') == 'detached' or status.get('bridge_refresh') is False
                        except (OSError, ValueError):
                            return 0.25
                    if not alive or detached:
                        session.launch(executable, folder)
                        _delivery_timers.discard(ensure_delivery)
                        return None
                except (OSError, ValueError) as error:
                    print('Art Inspector refresh delivery:', error)
                    try:
                        session.write_json(folder/'status.json', dict(state='delivery_failed', error=str(error)))
                    except OSError:
                        pass
                    _delivery_timers.discard(ensure_delivery)
                    return None
                return 0.25
            _delivery_timers.add(ensure_delivery)
            bpy.app.timers.register(ensure_delivery, first_interval=0.25)
            return folder, pid, len(selected) - len(meshes)
        if child is None or child.poll() is not None:
            # If the progress viewer closed or failed during a long export,
            # complete this Export action once with the now-ready FBX.
            child = session.launch(executable, folder)
        return folder, child.pid, len(selected) - len(meshes)
    except BaseException as error:
        try:
            (folder / 'diagnostic.txt').write_text(str(error), encoding='utf-8')
        except OSError:
            pass
        try:
            session.write_export_state(folder, 'failed')
            if not early_viewer:
                session.write_json(folder / "status.json", dict(state="export_or_launch_failed", error=str(error)))
        except OSError:
            pass  # Preserve the original, actionable error (e.g. disk full).
        raise
    finally:
        # Also remove exporter-owned mesh copies if its exception path leaked them.
        for mesh in set(bpy.data.meshes) - existing_meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        context.window_manager.progress_end()
        lease.close()


class ARTINSPECTOR_OT_export(bpy.types.Operator):
    bl_idname = "art_inspector.export"
    bl_label = "Export"
    bl_description = "Inspect selected meshes using the Export Mode selected in Preferences"

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        try:
            folder, pid, skipped = export_selection(context, bpy.path.abspath(prefs.executable) if prefs.executable else "", prefs.export_mode)
            message = f"Sent to Art Inspector (PID {pid})"
            if skipped:
                message += f"; skipped {skipped} non-Mesh object(s)"
            self.report({'WARNING'} if skipped else {'INFO'}, message)
            return {'FINISHED'}
        except Exception as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class ARTINSPECTOR_PT_bridge(bpy.types.Panel):
    bl_label = "Art Inspector"
    bl_idname = "ARTINSPECTOR_PT_bridge"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Art Inspector'

    def draw(self, context):
        self.layout.label(text=f"Selected Objects: {sum(o.type == 'MESH' for o in context.selected_objects)} Meshes")
        self.layout.operator(ARTINSPECTOR_OT_export.bl_idname, text="Export")
        if context.mode != 'OBJECT':
            self.layout.label(text="Switch to Object Mode", icon='INFO')


CLASSES = (BridgePreferences, ARTINSPECTOR_OT_export, ARTINSPECTOR_PT_bridge)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    if reset_document_identity not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(reset_document_identity)


def unregister():
    for callback in tuple(_delivery_timers):
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    _delivery_timers.clear()
    if reset_document_identity in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(reset_document_identity)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
